/*
 *  scale by an arbitrary factor > 1 and < 8, an input
 *  buffer at one resolution to an output buffer at a different
 *  resolution.
 */

void scalearb(unsigned char *ibm, unsigned char *obm, double f, unsigned long *wp, unsigned long *lp);

